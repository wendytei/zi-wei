-- 紫微斗数平台：第一阶段数据库结构
-- 所有用户私有数据都开启了行级权限（RLS）：每个人只能看到、修改自己的资料。
-- 农历生日不单独存储：它由出生日期计算得出，避免重复数据（计算在第二阶段实现）。

-- ───────── 用户资料 ─────────
create table public.profiles (
  id uuid primary key references auth.users (id) on delete cascade,
  display_name text,
  role text not null default 'user' check (role in ('user', 'admin')),
  locale text not null default 'zh-CN',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create or replace function public.is_admin()
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select exists (
    select 1 from public.profiles where id = (select auth.uid()) and role = 'admin'
  );
$$;

create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  insert into public.profiles (id, display_name)
  values (new.id, new.raw_user_meta_data ->> 'display_name');
  return new;
end;
$$;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- ───────── 出生资料 ─────────
create table public.birth_profiles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users (id) on delete cascade,
  name text not null check (char_length(name) between 1 and 50),
  gender text not null check (gender in ('male', 'female')),
  birth_date date not null,
  birth_time time not null,
  birth_location text,
  timezone text not null default 'Asia/Shanghai',
  notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index birth_profiles_user_idx on public.birth_profiles (user_id);

-- ───────── 排盘结果（按规则版本缓存，同一人同一规则不重复保存）─────────
create table public.chart_calculations (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users (id) on delete cascade,
  birth_profile_id uuid not null references public.birth_profiles (id) on delete cascade,
  rule_set text not null,
  engine_version text not null,
  result jsonb not null,
  created_at timestamptz not null default now(),
  unique (birth_profile_id, rule_set, engine_version)
);
create index chart_calculations_user_idx on public.chart_calculations (user_id);

create table public.saved_charts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users (id) on delete cascade,
  chart_calculation_id uuid not null references public.chart_calculations (id) on delete cascade,
  title text not null,
  created_at timestamptz not null default now()
);
create index saved_charts_user_idx on public.saved_charts (user_id);
create index saved_charts_calc_idx on public.saved_charts (chart_calculation_id);

-- ───────── AI 解读记录 ─────────
create table public.interpretations (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users (id) on delete cascade,
  chart_calculation_id uuid not null references public.chart_calculations (id) on delete cascade,
  category text not null,
  provider text not null,
  model text not null,
  content text not null,
  created_at timestamptz not null default now()
);
create index interpretations_user_idx on public.interpretations (user_id);
create index interpretations_calc_idx on public.interpretations (chart_calculation_id);

-- ───────── 报告 ─────────
create table public.reports (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users (id) on delete cascade,
  chart_calculation_id uuid references public.chart_calculations (id) on delete set null,
  title text not null,
  sections jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index reports_user_idx on public.reports (user_id);
create index reports_calc_idx on public.reports (chart_calculation_id);

-- ───────── 课堂 ─────────
create table public.courses (
  id uuid primary key default gen_random_uuid(),
  slug text not null unique,
  title text not null,
  description text,
  published boolean not null default false,
  sort_order int not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.lessons (
  id uuid primary key default gen_random_uuid(),
  course_id uuid not null references public.courses (id) on delete cascade,
  slug text not null,
  title text not null,
  content text not null default '',
  published boolean not null default false,
  sort_order int not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (course_id, slug)
);
create index lessons_course_idx on public.lessons (course_id);

create table public.lesson_progress (
  user_id uuid not null references auth.users (id) on delete cascade,
  lesson_id uuid not null references public.lessons (id) on delete cascade,
  completed boolean not null default false,
  bookmarked boolean not null default false,
  completed_at timestamptz,
  primary key (user_id, lesson_id)
);
create index lesson_progress_lesson_idx on public.lesson_progress (lesson_id);

create table public.user_notes (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users (id) on delete cascade,
  lesson_id uuid references public.lessons (id) on delete set null,
  body text not null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index user_notes_user_idx on public.user_notes (user_id);
create index user_notes_lesson_idx on public.user_notes (lesson_id);

-- ───────── 系统设置（只有管理员能改）─────────
create table public.app_settings (
  key text primary key,
  value jsonb not null,
  is_public boolean not null default false,
  updated_at timestamptz not null default now()
);

-- ───────── 行级权限 ─────────
alter table public.profiles enable row level security;
alter table public.birth_profiles enable row level security;
alter table public.chart_calculations enable row level security;
alter table public.saved_charts enable row level security;
alter table public.interpretations enable row level security;
alter table public.reports enable row level security;
alter table public.courses enable row level security;
alter table public.lessons enable row level security;
alter table public.lesson_progress enable row level security;
alter table public.user_notes enable row level security;
alter table public.app_settings enable row level security;

-- 个人资料：只能看/改自己的；角色不能自己改
create policy "profiles_select_own" on public.profiles
  for select to authenticated using ((select auth.uid()) = id);
create policy "profiles_update_own" on public.profiles
  for update to authenticated
  using ((select auth.uid()) = id)
  with check ((select auth.uid()) = id and role = (select p.role from public.profiles p where p.id = (select auth.uid())));

-- 个人私有数据：只能操作自己的
create policy "birth_profiles_own" on public.birth_profiles
  for all to authenticated
  using ((select auth.uid()) = user_id) with check ((select auth.uid()) = user_id);

create policy "chart_calculations_own" on public.chart_calculations
  for all to authenticated
  using ((select auth.uid()) = user_id) with check ((select auth.uid()) = user_id);

create policy "saved_charts_own" on public.saved_charts
  for all to authenticated
  using ((select auth.uid()) = user_id) with check ((select auth.uid()) = user_id);

create policy "interpretations_own" on public.interpretations
  for all to authenticated
  using ((select auth.uid()) = user_id) with check ((select auth.uid()) = user_id);

create policy "reports_own" on public.reports
  for all to authenticated
  using ((select auth.uid()) = user_id) with check ((select auth.uid()) = user_id);

create policy "lesson_progress_own" on public.lesson_progress
  for all to authenticated
  using ((select auth.uid()) = user_id) with check ((select auth.uid()) = user_id);

create policy "user_notes_own" on public.user_notes
  for all to authenticated
  using ((select auth.uid()) = user_id) with check ((select auth.uid()) = user_id);

-- 课程：登录用户可读已发布内容；管理员可增删改
create policy "courses_read_published" on public.courses
  for select to authenticated using (published or public.is_admin());
create policy "courses_admin_write" on public.courses
  for all to authenticated using (public.is_admin()) with check (public.is_admin());

create policy "lessons_read_published" on public.lessons
  for select to authenticated using (published or public.is_admin());
create policy "lessons_admin_write" on public.lessons
  for all to authenticated using (public.is_admin()) with check (public.is_admin());

-- 系统设置：公开项登录用户可读；其余与修改仅管理员
create policy "app_settings_read" on public.app_settings
  for select to authenticated using (is_public or public.is_admin());
create policy "app_settings_admin_write" on public.app_settings
  for all to authenticated using (public.is_admin()) with check (public.is_admin());
