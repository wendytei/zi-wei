import Link from "next/link";
import { AuthShell } from "@/components/auth-shell";
import { AuthForm } from "@/components/auth-form";
import { signup } from "@/app/auth/actions";

export default function SignupPage() {
  return (
    <AuthShell
      title="创建账号"
      subtitle="保存你和家人的出生资料与命盘"
      footer={
        <>
          已有账号？{" "}
          <Link href="/login" className="text-accent">
            去登录
          </Link>
        </>
      }
    >
      <AuthForm
        action={signup}
        submitLabel="注册"
        fields={[
          { name: "name", label: "你的称呼", type: "text", autoComplete: "name" },
          { name: "email", label: "邮箱", type: "email", autoComplete: "email" },
          { name: "password", label: "密码（至少 8 位）", type: "password", autoComplete: "new-password" },
        ]}
      />
    </AuthShell>
  );
}
