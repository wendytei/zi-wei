"use server";

import { headers } from "next/headers";
import { redirect } from "next/navigation";
import { z } from "zod";
import { createClient } from "@/lib/supabase/server";

export type FormState = { error?: string; message?: string };

const email = z.string().trim().email("请输入正确的邮箱");
const password = z.string().min(8, "密码至少需要 8 位");

async function getOrigin() {
  const h = await headers();
  return h.get("origin") ?? `https://${h.get("host")}`;
}

export async function login(_: FormState, formData: FormData): Promise<FormState> {
  const parsed = z
    .object({ email, password: z.string().min(1, "请输入密码") })
    .safeParse({ email: formData.get("email"), password: formData.get("password") });
  if (!parsed.success) return { error: parsed.error.issues[0].message };

  const supabase = await createClient();
  const { error } = await supabase.auth.signInWithPassword(parsed.data);
  if (error) return { error: "邮箱或密码不正确" };

  redirect("/dashboard");
}

export async function signup(_: FormState, formData: FormData): Promise<FormState> {
  const parsed = z
    .object({ name: z.string().trim().min(1, "请输入你的称呼").max(50), email, password })
    .safeParse({
      name: formData.get("name"),
      email: formData.get("email"),
      password: formData.get("password"),
    });
  if (!parsed.success) return { error: parsed.error.issues[0].message };

  const supabase = await createClient();
  const { data, error } = await supabase.auth.signUp({
    email: parsed.data.email,
    password: parsed.data.password,
    options: {
      data: { display_name: parsed.data.name },
      emailRedirectTo: `${await getOrigin()}/auth/callback`,
    },
  });
  if (error) return { error: "注册没有成功，请稍后再试，或换一个邮箱" };

  if (data.session) redirect("/dashboard");
  return { message: "注册成功！请到邮箱点击确认链接，然后回来登录。" };
}

export async function requestPasswordReset(_: FormState, formData: FormData): Promise<FormState> {
  const parsed = z.object({ email }).safeParse({ email: formData.get("email") });
  if (!parsed.success) return { error: parsed.error.issues[0].message };

  const supabase = await createClient();
  await supabase.auth.resetPasswordForEmail(parsed.data.email, {
    redirectTo: `${await getOrigin()}/auth/callback?next=/reset-password`,
  });
  // 无论邮箱是否存在都给出同样的提示，避免被人用来探测谁注册过。
  return { message: "如果这个邮箱已注册，我们已发送重设密码的邮件，请查收。" };
}

export async function updatePassword(_: FormState, formData: FormData): Promise<FormState> {
  const parsed = z.object({ password }).safeParse({ password: formData.get("password") });
  if (!parsed.success) return { error: parsed.error.issues[0].message };

  const supabase = await createClient();
  const { error } = await supabase.auth.updateUser({ password: parsed.data.password });
  if (error) return { error: "修改失败，链接可能已过期，请重新申请" };

  redirect("/dashboard");
}

export async function logout() {
  const supabase = await createClient();
  await supabase.auth.signOut();
  redirect("/");
}
