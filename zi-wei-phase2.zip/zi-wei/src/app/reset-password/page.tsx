import { AuthShell } from "@/components/auth-shell";
import { AuthForm } from "@/components/auth-form";
import { updatePassword } from "@/app/auth/actions";

export default function ResetPasswordPage() {
  return (
    <AuthShell title="设置新密码" subtitle="请输入新的登录密码">
      <AuthForm
        action={updatePassword}
        submitLabel="保存新密码"
        fields={[
          { name: "password", label: "新密码（至少 8 位）", type: "password", autoComplete: "new-password" },
        ]}
      />
    </AuthShell>
  );
}
