import Link from "next/link";
import { AuthShell } from "@/components/auth-shell";
import { AuthForm } from "@/components/auth-form";
import { login } from "@/app/auth/actions";

export default function LoginPage() {
  return (
    <AuthShell
      title="欢迎回来"
      subtitle="登录后查看你的命盘和资料"
      footer={
        <>
          还没有账号？{" "}
          <Link href="/signup" className="text-accent">
            免费注册
          </Link>
        </>
      }
    >
      <AuthForm
        action={login}
        submitLabel="登录"
        fields={[
          { name: "email", label: "邮箱", type: "email", autoComplete: "email" },
          { name: "password", label: "密码", type: "password", autoComplete: "current-password" },
        ]}
      />
      <p className="mt-4 text-center text-sm">
        <Link href="/forgot-password" className="text-muted hover:text-foreground">
          忘记密码？
        </Link>
      </p>
    </AuthShell>
  );
}
