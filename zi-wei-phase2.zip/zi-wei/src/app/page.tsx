import Link from "next/link";
import { ThemeToggle } from "@/components/theme-toggle";

export default function HomePage() {
  return (
    <main className="mx-auto flex min-h-screen max-w-5xl flex-col px-5">
      <header className="flex items-center justify-between py-5">
        <span className="font-serif text-xl font-bold tracking-widest">紫微斗数</span>
        <nav className="flex items-center gap-3 text-sm">
          <ThemeToggle />
          <Link href="/login" className="text-muted hover:text-foreground">
            登录
          </Link>
          <Link
            href="/signup"
            className="rounded-full bg-accent px-4 py-2 text-accent-foreground hover:opacity-90"
          >
            免费注册
          </Link>
        </nav>
      </header>

      <section className="flex flex-1 flex-col items-center justify-center py-20 text-center">
        <p className="mb-4 text-sm tracking-[0.3em] text-gold">排盘 · 解读 · 学习</p>
        <h1 className="font-serif text-4xl font-bold leading-tight sm:text-6xl">
          一个清爽、专业的
          <br />
          紫微斗数工具
        </h1>
        <p className="mt-6 max-w-xl text-muted">
          保存你和家人的出生资料，查看命盘，学习紫微斗数。界面简洁，不堆砌信息。
        </p>
        <div className="mt-10 flex gap-3">
          <Link
            href="/signup"
            className="rounded-full bg-accent px-7 py-3 text-sm font-medium text-accent-foreground hover:opacity-90"
          >
            开始使用
          </Link>
          <Link
            href="/login"
            className="rounded-full border border-border px-7 py-3 text-sm font-medium hover:bg-surface"
          >
            我已有账号
          </Link>
        </div>
      </section>
    </main>
  );
}
