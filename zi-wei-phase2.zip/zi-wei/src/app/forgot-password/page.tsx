import Link from "next/link";
import { AuthShell } from "@/components/auth-shell";
import { AuthForm } from "@/components/auth-form";
import { requestPasswordReset } from "@/app/auth/actions";

export default function ForgotPasswordPage() {
  return (
    <AuthShell
      title="找回密码"
      subtitle="输入注册邮箱，我们会发一封重设密码的邮件"
      footer={
        <Link href="/login" className="text-accent">
          返回登录
        </Link>
      }
    >
      <AuthForm
        action={requestPasswordReset}
        submitLabel="发送邮件"
        fields={[{ name: "email", label: "邮箱", type: "email", autoComplete: "email" }]}
      />
    </AuthShell>
  );
}
