import Link from "next/link";
import { redirect } from "next/navigation";
import { ArrowLeft, Compass, Trash2 } from "lucide-react";
import { createClient } from "@/lib/supabase/server";
import { PersonForm } from "@/components/person-form";
import { deletePerson } from "./actions";

export default async function PeoplePage() {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) redirect("/login");

  const { data: people } = await supabase
    .from("birth_profiles")
    .select("id,name,gender,birth_date,birth_time")
    .order("created_at", { ascending: false });

  return (
    <main className="mx-auto max-w-5xl px-5 py-6">
      <Link href="/dashboard" className="inline-flex items-center gap-1 text-sm text-muted hover:text-foreground">
        <ArrowLeft size={16} /> 返回
      </Link>
      <h1 className="mt-4 font-serif text-3xl font-bold">出生资料与命盘</h1>
      <p className="mt-2 text-muted">添加一个人的出生信息，马上就能看到他的紫微命盘。</p>

      <div className="mt-8 grid gap-8 md:grid-cols-2">
        <section className="rounded-2xl border border-border bg-surface p-6">
          <h2 className="mb-4 font-serif text-lg font-bold">添加一个人</h2>
          <PersonForm />
          <p className="mt-4 text-xs text-muted">请按出生地的钟表时间填写（暂不做真太阳时校正）。</p>
        </section>

        <section>
          <h2 className="mb-4 font-serif text-lg font-bold">已保存的人（{people?.length ?? 0}）</h2>
          {!people?.length && <p className="text-sm text-muted">还没有，先在左边添加第一个吧。</p>}
          <ul className="space-y-3">
            {people?.map((p) => (
              <li key={p.id} className="flex items-center justify-between rounded-2xl border border-border bg-surface p-4">
                <div>
                  <p className="font-medium">
                    {p.name} <span className="text-sm text-muted">{p.gender === "male" ? "男" : "女"}</span>
                  </p>
                  <p className="text-sm text-muted">
                    {p.birth_date} {String(p.birth_time).slice(0, 5)}
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <Link href={`/dashboard/chart/${p.id}`} className="inline-flex h-9 items-center gap-1 rounded-full bg-accent px-4 text-sm text-accent-foreground">
                    <Compass size={15} /> 看命盘
                  </Link>
                  <form action={deletePerson}>
                    <input type="hidden" name="id" value={p.id} />
                    <button type="submit" aria-label={`删除${p.name}`} className="grid h-9 w-9 place-items-center rounded-full border border-border text-muted hover:text-accent">
                      <Trash2 size={15} />
                    </button>
                  </form>
                </div>
              </li>
            ))}
          </ul>
        </section>
      </div>
    </main>
  );
}
