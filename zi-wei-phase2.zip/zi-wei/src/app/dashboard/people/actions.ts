"use server";

import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { z } from "zod";
import { createClient } from "@/lib/supabase/server";
import type { FormState } from "@/app/auth/actions";

const schema = z.object({
  name: z.string().trim().min(1, "请填写名字").max(50, "名字太长了"),
  gender: z.enum(["male", "female"], { message: "请选择性别" }),
  birth_date: z
    .string()
    .regex(/^\d{4}-\d{2}-\d{2}$/, "请选择出生日期")
    .refine((v) => {
      const y = Number(v.slice(0, 4));
      return y >= 1901 && y <= 2099;
    }, "目前只支持 1901 到 2099 年出生"),
  birth_time: z.string().regex(/^\d{2}:\d{2}$/, "请选择出生时间"),
  birth_location: z.string().trim().max(100).optional(),
  notes: z.string().trim().max(500).optional(),
});

export async function addPerson(_: FormState, formData: FormData): Promise<FormState> {
  const parsed = schema.safeParse(Object.fromEntries(formData));
  if (!parsed.success) return { error: parsed.error.issues[0].message };

  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) redirect("/login");

  const { birth_location, notes, ...rest } = parsed.data;
  const { data, error } = await supabase
    .from("birth_profiles")
    .insert({ ...rest, birth_location: birth_location || null, notes: notes || null, user_id: user.id })
    .select("id")
    .single();
  if (error || !data) return { error: "保存没有成功，请稍后再试" };

  revalidatePath("/dashboard/people");
  redirect(`/dashboard/chart/${data.id}`);
}

export async function deletePerson(formData: FormData) {
  const id = z.string().uuid().safeParse(formData.get("id"));
  if (!id.success) return;
  const supabase = await createClient();
  await supabase.from("birth_profiles").delete().eq("id", id.data); // 数据库权限保证只能删自己的
  revalidatePath("/dashboard/people");
}
