import Link from "next/link";
import { notFound, redirect } from "next/navigation";
import { ArrowLeft } from "lucide-react";
import { createClient } from "@/lib/supabase/server";
import { computeChart, ENGINE_VERSION, RULE_SET, type ChartResult } from "@/lib/chart";
import { ChartBoard } from "@/components/chart-board";

export default async function ChartPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) redirect("/login");

  if (!/^[0-9a-f-]{36}$/i.test(id)) notFound();
  const { data: person } = await supabase.from("birth_profiles").select("*").eq("id", id).maybeSingle();
  if (!person) notFound();

  // 先找已经算好的结果，没有就现算并保存起来
  const { data: cached } = await supabase
    .from("chart_calculations")
    .select("result")
    .eq("birth_profile_id", id)
    .eq("rule_set", RULE_SET)
    .eq("engine_version", ENGINE_VERSION)
    .maybeSingle();

  let chart = cached?.result as ChartResult | undefined;
  if (!chart) {
    chart = computeChart(person.birth_date, String(person.birth_time), person.gender);
    await supabase.from("chart_calculations").insert({
      user_id: user.id,
      birth_profile_id: id,
      rule_set: RULE_SET,
      engine_version: ENGINE_VERSION,
      result: chart,
    });
  }

  return (
    <main className="mx-auto max-w-5xl px-5 py-6">
      <Link href="/dashboard/people" className="inline-flex items-center gap-1 text-sm text-muted hover:text-foreground">
        <ArrowLeft size={16} /> 返回名单
      </Link>
      <h1 className="mt-4 font-serif text-3xl font-bold">{person.name} 的命盘</h1>
      <p className="mb-6 mt-2 text-sm text-muted">手机上可以左右滑动查看整个盘。右上角彩色小标记是四化：禄 · 权 · 科 · 忌。</p>
      <ChartBoard chart={chart} name={person.name} />
    </main>
  );
}
