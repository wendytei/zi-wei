import Link from "next/link";
import { redirect } from "next/navigation";
import { Compass, BookOpen, FileText, Sparkles, UserRound } from "lucide-react";
import { createClient } from "@/lib/supabase/server";
import { logout } from "@/app/auth/actions";
import { ThemeToggle } from "@/components/theme-toggle";
import { Button } from "@/components/ui";

const modules = [
  { icon: UserRound, href: "/dashboard/people", title: "出生资料", desc: "保存你和家人的出生信息" },
  { icon: Compass, href: "/dashboard/people", title: "命盘", desc: "十二宫排盘与互动查看" },
  { icon: Sparkles, title: "AI 解读", desc: "用白话读懂你的命盘" },
  { icon: BookOpen, title: "课堂", desc: "从零开始学紫微斗数" },
  { icon: FileText, title: "报告", desc: "整理并导出专业报告" },
];

export default async function DashboardPage() {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) redirect("/login");

  const name = (user.user_metadata?.display_name as string | undefined) ?? "你好";

  return (
    <main className="mx-auto max-w-5xl px-5 py-6">
      <header className="flex items-center justify-between">
        <span className="font-serif text-xl font-bold tracking-widest">紫微斗数</span>
        <div className="flex items-center gap-3">
          <ThemeToggle />
          <form action={logout}>
            <Button type="submit" variant="ghost" className="h-9 px-4">
              退出登录
            </Button>
          </form>
        </div>
      </header>

      <section className="mt-10">
        <h1 className="font-serif text-3xl font-bold">欢迎，{name}</h1>
        <p className="mt-2 text-muted">出生资料和命盘已经可以用了，其余功能会陆续开放。</p>
      </section>

      <section className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {modules.map(({ icon: Icon, title, desc, href }) => {
          const body = (
            <>
              <div className="flex items-center justify-between">
                <Icon size={22} className="text-gold" />
                {!href && (
                  <span className="rounded-full border border-border px-2.5 py-0.5 text-xs text-muted">即将开放</span>
                )}
              </div>
              <h2 className="mt-4 font-serif text-lg font-bold">{title}</h2>
              <p className="mt-1 text-sm text-muted">{desc}</p>
            </>
          );
          const cls = "rounded-2xl border border-border bg-surface p-5";
          return href ? (
            <Link key={title} href={href} className={`${cls} transition hover:border-accent`}>{body}</Link>
          ) : (
            <div key={title} className={cls}>{body}</div>
          );
        })}
      </section>
    </main>
  );
}
