import type { ChartResult, ChartPalace, ChartStar } from "@/lib/chart";

// 十二宫在 4×4 盘面上的位置：[行, 列]，key 是宫位序号（0=寅 … 11=丑）
const POS: Record<number, [number, number]> = {
  3: [1, 1], 4: [1, 2], 5: [1, 3], 6: [1, 4],
  2: [2, 1], 7: [2, 4],
  1: [3, 1], 8: [3, 4],
  0: [4, 1], 11: [4, 2], 10: [4, 3], 9: [4, 4],
};

const MUTAGEN_STYLE: Record<string, string> = {
  禄: "bg-emerald-600 text-white",
  权: "bg-blue-600 text-white",
  科: "bg-amber-500 text-white",
  忌: "bg-accent text-accent-foreground",
};

function Star({ s, major }: { s: ChartStar; major?: boolean }) {
  return (
    <span className={`inline-flex items-center gap-0.5 whitespace-nowrap ${major ? "font-serif text-[15px] font-bold" : "text-xs text-muted"}`}>
      {s.name}
      {s.brightness && <span className="text-[10px] font-normal text-gold">{s.brightness}</span>}
      {s.mutagen && (
        <span className={`rounded px-1 text-[10px] font-normal leading-4 ${MUTAGEN_STYLE[s.mutagen] ?? ""}`}>{s.mutagen}</span>
      )}
    </span>
  );
}

function Palace({ p }: { p: ChartPalace }) {
  const [row, col] = POS[p.index];
  return (
    <div
      style={{ gridRow: row, gridColumn: col }}
      className={`flex min-h-[150px] flex-col justify-between border border-border p-2 ${p.name === "命宫" ? "bg-accent/5" : "bg-surface"}`}
    >
      <div className="flex flex-wrap gap-x-2 gap-y-0.5">
        {p.major.map((s) => <Star key={s.name} s={s} major />)}
        {p.minor.map((s) => <Star key={s.name} s={s} />)}
      </div>
      <div className="mt-2 flex items-end justify-between text-xs">
        <span className="text-muted">{p.decadal[0]}–{p.decadal[1]}</span>
        <span className="text-right">
          <span className="block font-serif text-sm font-bold text-accent">
            {p.name}{p.isBody && <span className="ml-1 rounded bg-gold px-1 text-[10px] font-normal text-white">身</span>}
          </span>
          <span className="text-muted">{p.stem}{p.branch}</span>
        </span>
      </div>
    </div>
  );
}

export function ChartBoard({ chart, name }: { chart: ChartResult; name: string }) {
  const info: [string, string][] = [
    ["公历", chart.solarDate],
    ["农历", chart.lunarDate],
    ["四柱", chart.chineseDate],
    ["时辰", `${chart.time} ${chart.timeRange}`],
    ["生肖/星座", `${chart.zodiac} · ${chart.sign}`],
    ["五行局", chart.fiveElementsClass],
    ["命主 / 身主", `${chart.soul} / ${chart.body}`],
  ];
  return (
    <div className="overflow-x-auto">
      <div className="grid min-w-[760px] grid-cols-4 grid-rows-4">
        {chart.palaces.map((p) => <Palace key={p.index} p={p} />)}
        <div style={{ gridRow: "2 / 4", gridColumn: "2 / 4" }} className="flex flex-col justify-center border border-border bg-background p-5">
          <h2 className="text-center font-serif text-2xl font-bold">{name}</h2>
          <dl className="mt-3 space-y-1 text-sm">
            {info.map(([k, v]) => (
              <div key={k} className="flex justify-between gap-4">
                <dt className="text-muted">{k}</dt>
                <dd className="text-right">{v}</dd>
              </div>
            ))}
          </dl>
        </div>
      </div>
    </div>
  );
}
