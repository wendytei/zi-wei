"use client";

import { useActionState } from "react";
import { Button, Field } from "@/components/ui";
import { addPerson } from "@/app/dashboard/people/actions";

export function PersonForm() {
  const [state, formAction, pending] = useActionState(addPerson, {});
  return (
    <form action={formAction} className="space-y-4">
      <Field label="名字（或称呼）" name="name" required maxLength={50} placeholder="例如：我自己、妈妈" />
      <fieldset>
        <legend className="mb-1.5 text-sm text-muted">性别</legend>
        <div className="flex gap-3">
          {[
            ["male", "男"],
            ["female", "女"],
          ].map(([v, l]) => (
            <label key={v} className="flex h-11 flex-1 cursor-pointer items-center justify-center rounded-xl border border-border bg-surface text-sm has-[:checked]:border-accent has-[:checked]:text-accent">
              <input type="radio" name="gender" value={v} required className="sr-only" />
              {l}
            </label>
          ))}
        </div>
      </fieldset>
      <div className="grid grid-cols-2 gap-3">
        <Field label="出生日期（公历）" name="birth_date" type="date" required min="1901-01-01" max="2099-12-31" />
        <Field label="出生时间" name="birth_time" type="time" required />
      </div>
      <Field label="出生地（选填）" name="birth_location" maxLength={100} placeholder="例如：广州" />
      <Field label="备注（选填）" name="notes" maxLength={500} />
      {state.error && <p className="text-sm text-accent">{state.error}</p>}
      <Button type="submit" disabled={pending} className="w-full">
        {pending ? "排盘中…" : "保存并排盘"}
      </Button>
    </form>
  );
}
