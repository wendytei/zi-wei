"use client";

import { useActionState } from "react";
import { Button, Field } from "@/components/ui";
import type { FormState } from "@/app/auth/actions";

type FieldConfig = {
  name: string;
  label: string;
  type: string;
  autoComplete?: string;
};

export function AuthForm({
  action,
  fields,
  submitLabel,
}: {
  action: (state: FormState, formData: FormData) => Promise<FormState>;
  fields: FieldConfig[];
  submitLabel: string;
}) {
  const [state, formAction, pending] = useActionState(action, {});

  return (
    <form action={formAction} className="space-y-4">
      {fields.map((f) => (
        <Field key={f.name} required {...f} />
      ))}
      {state.error && <p className="text-sm text-accent">{state.error}</p>}
      {state.message && <p className="text-sm text-gold">{state.message}</p>}
      <Button type="submit" disabled={pending} className="w-full">
        {pending ? "请稍候…" : submitLabel}
      </Button>
    </form>
  );
}
