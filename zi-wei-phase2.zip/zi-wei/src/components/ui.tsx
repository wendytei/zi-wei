import type { ButtonHTMLAttributes, InputHTMLAttributes } from "react";

export function Button({
  className = "",
  variant = "primary",
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement> & { variant?: "primary" | "ghost" }) {
  const styles =
    variant === "primary"
      ? "bg-accent text-accent-foreground hover:opacity-90"
      : "border border-border text-foreground hover:bg-surface";
  return (
    <button
      className={`inline-flex h-11 items-center justify-center rounded-full px-6 text-sm font-medium transition disabled:opacity-60 ${styles} ${className}`}
      {...props}
    />
  );
}

export function Field({
  label,
  ...props
}: InputHTMLAttributes<HTMLInputElement> & { label: string }) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-sm text-muted">{label}</span>
      <input
        className="h-11 w-full rounded-xl border border-border bg-surface px-4 text-sm outline-none transition focus:border-accent"
        {...props}
      />
    </label>
  );
}
