import { astro } from "iztro";

// 排盘规则标记：以后如果换规则或升级引擎，旧结果不会被覆盖。
export const RULE_SET = "iztro-default-zh";
export const ENGINE_VERSION = "iztro-2.6.5";

export type ChartStar = { name: string; brightness: string; mutagen: string };
export type ChartPalace = {
  index: number; // 0 = 寅宫 … 11 = 丑宫
  name: string;
  stem: string;
  branch: string;
  isBody: boolean;
  major: ChartStar[];
  minor: ChartStar[];
  decadal: [number, number];
};
export type ChartResult = {
  solarDate: string;
  lunarDate: string;
  chineseDate: string;
  time: string;
  timeRange: string;
  sign: string;
  zodiac: string;
  fiveElementsClass: string;
  soul: string;
  body: string;
  soulBranch: string;
  bodyBranch: string;
  palaces: ChartPalace[];
};

// 钟点 → iztro 的时辰序号（0=早子 1=丑 … 11=亥 12=晚子）
export function timeToIndex(hhmm: string): number {
  const h = Number(hhmm.slice(0, 2));
  if (h === 0) return 0;
  if (h === 23) return 12;
  return Math.floor((h + 1) / 2);
}

const star = (s: { name: string; brightness?: string; mutagen?: string }): ChartStar => ({
  name: s.name,
  brightness: s.brightness ?? "",
  mutagen: s.mutagen ?? "",
});

export function computeChart(birthDate: string, birthTime: string, gender: "male" | "female"): ChartResult {
  const [y, m, d] = birthDate.split("-").map(Number);
  const c = astro.bySolar(`${y}-${m}-${d}`, timeToIndex(birthTime), gender === "male" ? "男" : "女", true, "zh-CN");
  return {
    solarDate: c.solarDate,
    lunarDate: c.lunarDate,
    chineseDate: c.chineseDate,
    time: c.time,
    timeRange: c.timeRange,
    sign: c.sign,
    zodiac: c.zodiac,
    fiveElementsClass: c.fiveElementsClass,
    soul: c.soul,
    body: c.body,
    soulBranch: c.earthlyBranchOfSoulPalace,
    bodyBranch: c.earthlyBranchOfBodyPalace,
    palaces: c.palaces.map((p) => ({
      index: p.index,
      name: p.name,
      stem: p.heavenlyStem,
      branch: p.earthlyBranch,
      isBody: p.isBodyPalace,
      major: p.majorStars.map(star),
      minor: p.minorStars.map(star),
      decadal: [p.decadal.range[0], p.decadal.range[1]],
    })),
  };
}
